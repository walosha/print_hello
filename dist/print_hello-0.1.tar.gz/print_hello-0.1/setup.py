from setuptools import setup

setup(name='print_hello',
      version='0.1',
      description='The print hello function that accept a messg',
      url='https://github.com/walosha/print_hello',
      author='Olawale Afuye',
      author_email='walosha@yahoo.com',
      license='MIT',
      packages=[],
      zip_safe=False)
